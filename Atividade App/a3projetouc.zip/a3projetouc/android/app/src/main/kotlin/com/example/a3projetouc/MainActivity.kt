package com.example.a3projetouc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
